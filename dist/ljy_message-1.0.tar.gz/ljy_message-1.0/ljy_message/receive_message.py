def receive():
    return "这是来自100xx的短信"